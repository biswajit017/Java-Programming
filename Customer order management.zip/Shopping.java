// package Customer_Order_Management.java;

public class Shopping {

    public static void main(String[] args) {
        
        Order o1 = new Order ("11"," Double Cheese Pizza");
        Customer c1 = new Customer("Biswajit" , "biswajit@gmail.com" , o1);

        System.out.println( c1);
    }
    
}
